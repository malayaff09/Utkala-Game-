function generateResult() {
  const number = Math.floor(Math.random() * 10 + 1);
  const color = [1, 3, 7, 9].includes(number) ? 'Red' : [2, 4, 6, 8, 10].includes(number) ? 'Green' : 'Violet';
  const bigsmall = number > 5 ? 'Big' : 'Small';

  document.getElementById("number").innerText = number;
  document.getElementById("color").innerText = color;
  document.getElementById("bigsmall").innerText = bigsmall;
}
