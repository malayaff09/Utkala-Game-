
console.log("Utkala Game loaded successfully!");
